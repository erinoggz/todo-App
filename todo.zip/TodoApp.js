export default class App extends Component{
    constructor(props){
      super(props)
      this.state={
        text: "",
        todo: []
      }
    }
    addTodo=()=> {
      let newTodo = this.state.text;
      let arrays= this.state.todo;
      arrays.push(newTodo);
      this.setState({todo: arrays, text: ""})
    }
    deleteTodo=(t) => {
     var arrays = this.state.todo;
     var pos = arrays.indexOf(t)
     arrays.splice(pos,1)
     this.setState({todo: arrays})
    }
    renderTodos=()=> {
      return this.state.todo.map(t=> {
        return (<Text style={styles.todolist} 
          onPress={()=> {this.deleteTodo(t)}} key={t}>{t}</Text>)
      })
    }
    render(){
      return(
        <View  style={{backgroundColor: 'snow'}}>
        <View style={{marginTop: 18}}>
          <Text style={styles.welcome}>OGgz Todo App!</Text>
            <TextInput style={styles.inputtext}
            keyboardType='default'
            placeholder="Enter Items Here"
            placeholderTextColor="orange"
            onChangeText={(text)=> this.setState(()=> {return {text}})}
            value={this.state.text}
            />
    
            <View style={{alignItems: 'center', justifyContent: "center"}}>
            <Button title="Add Item"
            color="orange"
            onPress={this.addTodo}
            />
            </View>
            <Text style={{marginLeft: 10, marginTop: 3, fontSize: 12}}>NB: Tap on Item to remove</Text>
            {this.renderTodos()}
        </View>
        </View>
      )
    }
    }
    
    const styles=StyleSheet.create({
      welcome: {
        marginLeft: 'auto', 
        marginRight: 'auto', 
        marginTop: 10,
        fontSize: 40
      },
      todolist:{
        marginLeft: 300,
        fontSize: 14
      },
      inputtext: {
        height: 40,
        margin: 10,
        padding: 10,
        borderBottomColor: 'orange',
        borderBottomWidth: 1,
        borderRightWidth: 1,
        borderLeftWidth: 1,
        borderRadius: 20
      }
    })